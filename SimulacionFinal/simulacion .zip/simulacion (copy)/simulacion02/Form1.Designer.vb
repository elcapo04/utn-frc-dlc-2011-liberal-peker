<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rtxtResultados = New System.Windows.Forms.RichTextBox
        Me.txtSeed = New System.Windows.Forms.TextBox
        Me.btmGenerar = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtK = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtMu = New System.Windows.Forms.TextBox
        Me.txtRho = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtLamda = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtSubintervalos = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.rbtmExponencial = New System.Windows.Forms.RadioButton
        Me.rbtmNormal = New System.Windows.Forms.RadioButton
        Me.rbtmPoisson = New System.Windows.Forms.RadioButton
        Me.txtNumeros = New System.Windows.Forms.TextBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.btmLimpiar = New System.Windows.Forms.Button
        Me.psbProgreso = New System.Windows.Forms.ProgressBar
        Me.lblStatus = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'rtxtResultados
        '
        Me.rtxtResultados.BackColor = System.Drawing.Color.White
        Me.rtxtResultados.Location = New System.Drawing.Point(5, 28)
        Me.rtxtResultados.Name = "rtxtResultados"
        Me.rtxtResultados.ReadOnly = True
        Me.rtxtResultados.Size = New System.Drawing.Size(326, 133)
        Me.rtxtResultados.TabIndex = 0
        Me.rtxtResultados.TabStop = False
        Me.rtxtResultados.Text = ""
        '
        'txtSeed
        '
        Me.txtSeed.Location = New System.Drawing.Point(139, 16)
        Me.txtSeed.MaxLength = 10
        Me.txtSeed.Name = "txtSeed"
        Me.txtSeed.Size = New System.Drawing.Size(114, 20)
        Me.txtSeed.TabIndex = 0
        Me.txtSeed.Text = "0"
        Me.txtSeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btmGenerar
        '
        Me.btmGenerar.Location = New System.Drawing.Point(286, 128)
        Me.btmGenerar.Name = "btmGenerar"
        Me.btmGenerar.Size = New System.Drawing.Size(161, 42)
        Me.btmGenerar.TabIndex = 4
        Me.btmGenerar.Text = "Generar"
        Me.btmGenerar.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtK)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtMu)
        Me.GroupBox1.Controls.Add(Me.txtRho)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtLamda)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtSubintervalos)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.txtNumeros)
        Me.GroupBox1.Controls.Add(Me.btmGenerar)
        Me.GroupBox1.Controls.Add(Me.txtSeed)
        Me.GroupBox1.Location = New System.Drawing.Point(4, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(453, 180)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Configuracion:"
        '
        'txtK
        '
        Me.txtK.Enabled = False
        Me.txtK.Location = New System.Drawing.Point(139, 154)
        Me.txtK.Name = "txtK"
        Me.txtK.Size = New System.Drawing.Size(114, 20)
        Me.txtK.TabIndex = 6
        Me.txtK.Text = "1"
        Me.txtK.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 157)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(16, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "k:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(3, 135)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(25, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Mu:"
        '
        'txtMu
        '
        Me.txtMu.Enabled = False
        Me.txtMu.Location = New System.Drawing.Point(139, 132)
        Me.txtMu.Name = "txtMu"
        Me.txtMu.Size = New System.Drawing.Size(114, 20)
        Me.txtMu.TabIndex = 5
        Me.txtMu.Text = "1"
        Me.txtMu.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtRho
        '
        Me.txtRho.Enabled = False
        Me.txtRho.Location = New System.Drawing.Point(139, 111)
        Me.txtRho.Name = "txtRho"
        Me.txtRho.Size = New System.Drawing.Size(114, 20)
        Me.txtRho.TabIndex = 4
        Me.txtRho.Text = "1"
        Me.txtRho.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(30, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Rho:"
        '
        'txtLamda
        '
        Me.txtLamda.Location = New System.Drawing.Point(139, 89)
        Me.txtLamda.Name = "txtLamda"
        Me.txtLamda.Size = New System.Drawing.Size(114, 20)
        Me.txtLamda.TabIndex = 3
        Me.txtLamda.Text = "1"
        Me.txtLamda.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(3, 92)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Lambda:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(3, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Cantidad de subintérvalos:"
        '
        'txtSubintervalos
        '
        Me.txtSubintervalos.Location = New System.Drawing.Point(139, 62)
        Me.txtSubintervalos.Name = "txtSubintervalos"
        Me.txtSubintervalos.Size = New System.Drawing.Size(114, 20)
        Me.txtSubintervalos.TabIndex = 2
        Me.txtSubintervalos.Text = "10"
        Me.txtSubintervalos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Semilla:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(3, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Números a generar:"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbtmExponencial)
        Me.GroupBox2.Controls.Add(Me.rbtmNormal)
        Me.GroupBox2.Controls.Add(Me.rbtmPoisson)
        Me.GroupBox2.Location = New System.Drawing.Point(286, 19)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(161, 103)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Seleccion de distribucion"
        '
        'rbtmExponencial
        '
        Me.rbtmExponencial.AutoSize = True
        Me.rbtmExponencial.Checked = True
        Me.rbtmExponencial.Location = New System.Drawing.Point(6, 19)
        Me.rbtmExponencial.Name = "rbtmExponencial"
        Me.rbtmExponencial.Size = New System.Drawing.Size(83, 17)
        Me.rbtmExponencial.TabIndex = 2
        Me.rbtmExponencial.TabStop = True
        Me.rbtmExponencial.Text = "Exponencial"
        Me.rbtmExponencial.UseVisualStyleBackColor = True
        '
        'rbtmNormal
        '
        Me.rbtmNormal.AutoSize = True
        Me.rbtmNormal.Location = New System.Drawing.Point(6, 65)
        Me.rbtmNormal.Name = "rbtmNormal"
        Me.rbtmNormal.Size = New System.Drawing.Size(58, 17)
        Me.rbtmNormal.TabIndex = 1
        Me.rbtmNormal.Text = "Normal"
        Me.rbtmNormal.UseVisualStyleBackColor = True
        '
        'rbtmPoisson
        '
        Me.rbtmPoisson.AutoSize = True
        Me.rbtmPoisson.Location = New System.Drawing.Point(6, 42)
        Me.rbtmPoisson.Name = "rbtmPoisson"
        Me.rbtmPoisson.Size = New System.Drawing.Size(62, 17)
        Me.rbtmPoisson.TabIndex = 0
        Me.rbtmPoisson.Text = "Poisson"
        Me.rbtmPoisson.UseVisualStyleBackColor = True
        '
        'txtNumeros
        '
        Me.txtNumeros.Location = New System.Drawing.Point(139, 39)
        Me.txtNumeros.Name = "txtNumeros"
        Me.txtNumeros.Size = New System.Drawing.Size(114, 20)
        Me.txtNumeros.TabIndex = 1
        Me.txtNumeros.Text = "100000"
        Me.txtNumeros.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.rtxtResultados)
        Me.GroupBox3.Location = New System.Drawing.Point(463, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(337, 180)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Resultados:"
        '
        'btmLimpiar
        '
        Me.btmLimpiar.Location = New System.Drawing.Point(719, 588)
        Me.btmLimpiar.Name = "btmLimpiar"
        Me.btmLimpiar.Size = New System.Drawing.Size(75, 23)
        Me.btmLimpiar.TabIndex = 6
        Me.btmLimpiar.Text = "Limpiar"
        Me.btmLimpiar.UseVisualStyleBackColor = True
        '
        'psbProgreso
        '
        Me.psbProgreso.Location = New System.Drawing.Point(184, 588)
        Me.psbProgreso.Name = "psbProgreso"
        Me.psbProgreso.Size = New System.Drawing.Size(526, 23)
        Me.psbProgreso.TabIndex = 5
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New System.Drawing.Point(17, 593)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(0, 13)
        Me.lblStatus.TabIndex = 6
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(811, 623)
        Me.Controls.Add(Me.btmLimpiar)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.psbProgreso)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.DoubleBuffered = True
        Me.Name = "Form1"
        Me.Text = "Laboratorio 3"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents rtxtResultados As System.Windows.Forms.RichTextBox
    Friend WithEvents txtSeed As System.Windows.Forms.TextBox
    Friend WithEvents btmGenerar As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbtmNormal As System.Windows.Forms.RadioButton
    Friend WithEvents rbtmPoisson As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btmLimpiar As System.Windows.Forms.Button
    Friend WithEvents rbtmExponencial As System.Windows.Forms.RadioButton
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtSubintervalos As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtNumeros As System.Windows.Forms.TextBox
    Friend WithEvents psbProgreso As System.Windows.Forms.ProgressBar
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents txtLamda As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtRho As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtMu As System.Windows.Forms.TextBox
    Friend WithEvents txtK As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label

End Class
