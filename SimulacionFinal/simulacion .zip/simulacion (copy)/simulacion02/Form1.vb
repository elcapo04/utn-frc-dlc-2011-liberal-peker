Public Class Form1
    Private brushBlack As New System.Drawing.SolidBrush(Color.Black)
    Private graficar As Boolean = False
    Private graficador As GeneradorDeGraficos
    Private gen As Generador
    Private Const GRAPHICWINDOW_WIDTH As Integer = 800
    Private Const GRAPHICWINDOW_HEIGHT As Integer = 380
    Private Const GRAPHICWINDOW_POSX As Integer = 4
    Private Const GRAPHICWINDOW_POSY As Integer = 200



    Private Sub btmGenerar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btmGenerar.Click
        Dim i, k, cantidad, subintervalos As Integer
        Dim seed, lamda, rho, mu As Double

        Try
            seed = Double.Parse(txtSeed.Text)
            If seed < 0 Then Throw New FormatException
        Catch ex As FormatException
            MessageBox.Show("La semilla debe tener un valor numerico positivo", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Exit Sub
        End Try
        Try
            cantidad = Integer.Parse(txtNumeros.Text)
            If cantidad < 0 Then Throw New FormatException
        Catch ex As FormatException
            MessageBox.Show("La cantidad de numeros debe ser un valor numerico entero positivo", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Exit Sub
        End Try
        Try
            subintervalos = Integer.Parse(txtSubintervalos.Text)
            If subintervalos < 1 Then Throw New FormatException
        Catch ex As FormatException
            MessageBox.Show("La cantidad de subintervalos debe ser un valor numerico entero positivo mayor o igual que 1", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Exit Sub
        End Try
        Try
            lamda = Double.Parse(txtLamda.Text)
            If lamda <= 0 Then Throw New FormatException
        Catch ex As FormatException
            MessageBox.Show("Lamda debe tener un valor numerico positivo", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Exit Sub
        End Try
        Try
            rho = Double.Parse(txtRho.Text)
        Catch ex As FormatException
            MessageBox.Show("Rho posee un valor incorrecto", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Exit Sub
        End Try
        Try
            mu = Double.Parse(txtMu.Text)
        Catch ex As FormatException
            MessageBox.Show("Mu posee un valor incorrecto", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Exit Sub
        End Try

        Try
            k = Integer.Parse(txtK.Text)
            If k < 0 Then Throw New FormatException
        Catch ex As FormatException
            MessageBox.Show("k posee un valor incorrecto", "Error de formato", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Exit Sub
        End Try



        rbtmPoisson.Enabled = False
        rbtmNormal.Enabled = False
        rbtmExponencial.Enabled = False
        btmGenerar.Enabled = False
        txtSeed.Enabled = False
        txtNumeros.Enabled = False
        txtSubintervalos.Enabled = False
        txtLamda.Enabled = False

        txtK.Enabled = False
        txtRho.Enabled = False
        txtMu.Enabled = False

        rtxtResultados.Text = ""
        Dim vector(subintervalos - 1) As Double
        Dim concatenador As New System.Text.StringBuilder
        lblStatus.Text = "Generando numeros aleatorios"
        lblStatus.Refresh()
        psbProgreso.Maximum = cantidad
        Try
            gen = New Generador(seed, lamda, rho, mu, k)
            If rbtmExponencial.Checked Then
                For i = 0 To cantidad - 1
                    psbProgreso.Value = i + 1
                    seed = gen.distribucionExponencial
                    llenarVector(vector, seed, subintervalos)
                    concatenador.Append(seed.ToString)
                    concatenador.Append(vbCrLf)
                Next
            ElseIf rbtmPoisson.Checked Then
                For i = 0 To cantidad - 1
                    'psbProgreso.Value = i + 1
                    vector = gen.distribucionPoisson
                    'llenarVector(vector, seed, subintervalos)
                    'concatenador.Append(seed.ToString)
                    'concatenador.Append(vbCrLf)
                Next


            Else
                    For i = 0 To cantidad - 1
                    psbProgreso.Value = i + 1
                    seed = gen.distribucionNormal
                    llenarVector(vector, seed, subintervalos)
                        concatenador.Append(seed.ToString)
                        concatenador.Append(vbCrLf)
                Next
            End If
        Catch ex As OverflowException
            MessageBox.Show("Se ha producido un desbordamiento de memoria, por favor ingrese numeros mas peque�os", "Desborde de memoria", MessageBoxButtons.OK, MessageBoxIcon.Error)
            psbProgreso.Value = 0
            lblStatus.Text = ""
            Exit Sub

        End Try
        rtxtResultados.Text = concatenador.ToString

        psbProgreso.Maximum = 100
        lblStatus.Text = "Graficando"
        lblStatus.Refresh()
        psbProgreso.Value = 30
        graficador = New GeneradorDeGraficos(vector)
        graficador.generarEjes()
        graficador.generarFuncion()

        graficar = True
        Me.Invalidate()

        psbProgreso.Value = 100
        lblStatus.Text = "Terminado"

    End Sub

    Private Sub llenarVector(ByRef vector() As Double, ByVal nro As Double, ByVal intervalo As Integer)

        Dim posicion As Integer = Int(nro)
        If posicion < intervalo Then vector(posicion) += 1


    End Sub
    Class Generador
        Private previous As Long
        Private random As Random
        Private inverseLamda As Double
        Private M As Long = 2 ^ 32
        Private inverseM As Double
        Private mu As Double
        Private rho As Double
        Private k As Integer
        Private lamda As Double
        Public Sub New(ByVal seed As Long, ByVal lamda As Double, ByVal rho As Double, ByVal mu As Double, ByVal k As Integer) ', ByVal A As Long, ByVal C As Long)
            inverseM = 1 / M
            inverseLamda = 1 / lamda
            previous = seed
            random = New Random(seed)
            Me.mu = mu
            Me.rho = rho
            Me.lamda = lamda
            Me.k = k
        End Sub

        Public Function distribucionExponencial() As Double

            Return -Math.Log(random.NextDouble) * inverseLamda
        End Function

        Public Function distribucionPoisson() As Double()
            'Dim kFact As Integer = 1
            'Dim exp As Double
            'exp = (lamda) '* random.NextDouble)
            'If k = 0 Then Return Math.Exp(-exp)
            'Dim i As Integer
            'For i = k To 1 Step -1
            'kFact = i * kFact
            'Next
            'Return Math.Pow(exp, k) * Math.Exp(-exp) / kFact
            Dim mult As Double = 1.0
            Dim vector(k - 1) As Double
            If k = 0 Then

                mult = Math.Exp(-lamda)

            Else
                Dim i As Integer = 1
                Dim fexp As Double = Math.Exp((-lamda) / (k + 1))
                mult = fexp
                While (i <= k)

                    mult *= ((lamda) / i) * fexp
                    'If i = 1 Then
                    vector(i - 1) = mult '((lamda) / i) * fexp
                    'Else
                    'vector(i - 1) = vector(i - 2) + mult
                    'End If
                    'System.out.println("\t" + i + "\t" + aux + "\t" + mult); */
                    i = i + 1

                End While


            End If
            Return vector





        End Function
        Public Function distribucionNormal() As Double
            Dim z As Double
            z = Math.Pow(-2 * Math.Log(random.NextDouble), 0.5) * Math.Cos(2 * Math.PI * random.NextDouble)
            Return mu + z * rho
        End Function
    End Class


    Private Sub btmLimpiar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btmLimpiar.Click
        rbtmPoisson.Enabled = True
        rbtmNormal.Enabled = True
        rbtmExponencial.Enabled = True
        btmGenerar.Enabled = True
        txtSeed.Enabled = True
        txtNumeros.Enabled = True
        txtSubintervalos.Enabled = True
        txtLamda.Enabled = True

        txtK.Enabled = True
        txtRho.Enabled = True
        txtMu.Enabled = True

        rtxtResultados.Text = ""
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)

        e.Graphics.FillRectangle(brushBlack, GRAPHICWINDOW_POSX, GRAPHICWINDOW_POSY, GRAPHICWINDOW_WIDTH, GRAPHICWINDOW_HEIGHT)
        If graficar Then
            graficador.graficarEjes(e.Graphics)
            graficador.graficarFuncion(e.Graphics)
        End If
    End Sub


    Class GeneradorDeGraficos
        Private puntos As New System.Collections.ObjectModel.Collection(Of Point)
        Private vector() As Double
        Private zeroCrossX As Integer = CInt(GRAPHICWINDOW_WIDTH * 0.1 + GRAPHICWINDOW_POSX)
        Private zeroCrossY As Integer = CInt(GRAPHICWINDOW_POSY + GRAPHICWINDOW_HEIGHT * 0.85)
        Private division As Single
        Private maxSize As Single


        Private media As Single

        Public Sub New(ByVal vector() As Double)
            Me.vector = vector
            division = GRAPHICWINDOW_WIDTH * 0.85 / vector.Length
            Dim max As Integer = 0
            Dim i As Integer
            For i = 0 To vector.Length - 1
                If max < vector(i) Then max = vector(i)
                'counter += vector(i)
            Next
            maxSize = GRAPHICWINDOW_HEIGHT * 0.8 / max



        End Sub
        Public Sub generarEjes()
            puntos.Add(New Point(CInt(GRAPHICWINDOW_WIDTH * 0.05 + GRAPHICWINDOW_POSX), CInt(GRAPHICWINDOW_HEIGHT * 0.85 + GRAPHICWINDOW_POSY)))
            puntos.Add(New Point(CInt(GRAPHICWINDOW_WIDTH * 0.95 + GRAPHICWINDOW_POSX), CInt(GRAPHICWINDOW_HEIGHT * 0.85 + GRAPHICWINDOW_POSY)))
            puntos.Add(New Point(CInt(GRAPHICWINDOW_WIDTH * 0.1 + GRAPHICWINDOW_POSX), CInt(GRAPHICWINDOW_HEIGHT * 0.05 + GRAPHICWINDOW_POSY)))
            puntos.Add(New Point(CInt(GRAPHICWINDOW_WIDTH * 0.1 + GRAPHICWINDOW_POSX), CInt(GRAPHICWINDOW_HEIGHT * 0.95 + GRAPHICWINDOW_POSY)))
        End Sub
        Public Sub graficarEjes(ByVal region As System.Drawing.Graphics)
            Dim ejeX(1) As Point
            Dim ejeY(1) As Point

            Dim intervalos(9) As Point
            ejeX(0) = New Point(puntos.Item(0))
            ejeX(1) = New Point(puntos.Item(1))
            ejeY(0) = New Point(puntos.Item(2))
            ejeY(1) = New Point(puntos.Item(3))

            Dim i As Integer

            For i = 0 To intervalos.Length - 1
                intervalos(i) = New Point(CInt(zeroCrossX + division * (i + 1) * vector.Length / 10), CInt(GRAPHICWINDOW_HEIGHT * 0.9 + GRAPHICWINDOW_POSY))
            Next
            region.DrawLines(Pens.White, ejeX)
            region.DrawLines(Pens.White, ejeY)
            Dim guide(1) As Point
            For i = 0 To intervalos.Length - 1
                region.DrawString((vector.Length / 10 * (i + 1)).ToString("#0.0"), New System.Drawing.Font("Arial", 10, FontStyle.Bold), Brushes.White, intervalos(i))

                guide(0) = New Point(intervalos(i).X, CInt(GRAPHICWINDOW_HEIGHT * 0.84 + GRAPHICWINDOW_POSY))
                guide(1) = New Point(intervalos(i).X, CInt(GRAPHICWINDOW_HEIGHT * 0.86 + GRAPHICWINDOW_POSY))
                region.DrawLines(Pens.BlueViolet, guide)
            Next
            region.DrawString("0", New System.Drawing.Font("Arial", 10, FontStyle.Bold), Brushes.White, CInt(GRAPHICWINDOW_WIDTH * 0.05 + GRAPHICWINDOW_POSX), CInt(GRAPHICWINDOW_HEIGHT * 0.9 + GRAPHICWINDOW_POSY))
            For i = 1 To 5
                Dim posy As Integer = CInt(zeroCrossY - GRAPHICWINDOW_HEIGHT * 0.8 / 5 * i)
                region.DrawString((i * 0.2).ToString("0.0"), New System.Drawing.Font("Arial", 10, FontStyle.Bold), Brushes.White, CInt(GRAPHICWINDOW_WIDTH * 0.05 + GRAPHICWINDOW_POSX), posY)
                guide(0) = New Point(CInt(GRAPHICWINDOW_WIDTH * 0.095 + GRAPHICWINDOW_POSX), posy)
                guide(1) = New Point(CInt(GRAPHICWINDOW_WIDTH * 0.105 + GRAPHICWINDOW_POSX), posy)
                region.DrawLines(Pens.BlueViolet, guide)

            Next

        End Sub

        Public Sub generarFuncion()

            Dim max As Integer = 0
            Dim intervalos As Integer = vector.Length
            Dim i As Integer
            'Dim counter As Integer = 0
            'Genero la media
            'media = counter / intervalos
            'puntos.Add(New Point(zeroCrossX, CInt(zeroCrossY - maxSize * media)))
            'puntos.Add(New Point(CInt(GRAPHICWINDOW_WIDTH * 0.95 + GRAPHICWINDOW_POSX), CInt(zeroCrossY - maxSize * media)))


            For i = 0 To intervalos - 1
                puntos.Add(New Point(CInt(zeroCrossX + division * (i + 1)), CInt(zeroCrossY - maxSize * vector(i))))

            Next
        End Sub
        Public Sub graficarFuncion(ByVal region As System.Drawing.Graphics)
            Dim points(vector.Length - 1) As Point
            Dim i As Integer

            For i = 4 To vector.Length() + 3
                points(i - 4) = puntos.Item(i)
            Next
            region.DrawLines(Pens.Green, points)
            'region.DrawLines(Pens.Red, extremos)
            'region.DrawString(Format(1 / vector.Length, "#0.00").ToString, New System.Drawing.Font("Arial", 7, FontStyle.Bold), Brushes.Red, GRAPHICWINDOW_POSX, extremos(0).Y)

        End Sub
    End Class

 
 
   
    Private Sub rbtmExponencial_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtmExponencial.Click
        txtLamda.Enabled = True
        txtK.Enabled = False
        txtRho.Enabled = False
        txtMu.Enabled = False
    End Sub

    Private Sub rbtmNormal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtmNormal.Click
        txtLamda.Enabled = False
        txtK.Enabled = False
        txtRho.Enabled = True
        txtMu.Enabled = True
    End Sub

    Private Sub rbtmPoisson_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtmPoisson.Click
        txtLamda.Enabled = True
        txtK.Enabled = True
        txtRho.Enabled = False
        txtMu.Enabled = False
    End Sub
End Class
